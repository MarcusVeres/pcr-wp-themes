<?php
/**
 * Elementor customizations
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Your Elementor customizations go below this line
 */