<?php
/**
 * ACF customizations
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Your ACF customizations go below this line
 */