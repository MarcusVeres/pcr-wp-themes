<?php
/**
 * WooCommerce customizations
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Add WooCommerce theme support
 */
function pcr_woocommerce_support() {
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'pcr_woocommerce_support');

/**
 * Register Artists taxonomy for products
 */
function pcr_register_artists_taxonomy() {
    $labels = array(
        'name'              => _x('Artists', 'taxonomy general name'),
        'singular_name'     => _x('Artist', 'taxonomy singular name'),
        'search_items'      => __('Search Artists'),
        'all_items'         => __('All Artists'),
        'parent_item'       => __('Parent Artist'),
        'parent_item_colon' => __('Parent Artist:'),
        'edit_item'         => __('Edit Artist'),
        'update_item'       => __('Update Artist'),
        'add_new_item'      => __('Add New Artist'),
        'new_item_name'     => __('New Artist Name'),
        'menu_name'         => __('Artists'),
    );

    $args = array(
        'hierarchical'      => false, // Like tags (artists aren't hierarchical)
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'show_in_nav_menus' => true,
        'show_tagcloud'     => false,
        'public'            => true,
        'publicly_queryable' => true,
        'rewrite'           => array('slug' => 'artist'),
        'show_in_rest'      => true, // For Gutenberg/REST API
        'meta_box_cb'       => false, // We'll use a custom meta box
    );

    register_taxonomy('product_artist', array('product'), $args);
}
add_action('init', 'pcr_register_artists_taxonomy');

/**
 * Add custom meta box for artists (easier to use than default)
 */
function pcr_add_artist_meta_box() {
    add_meta_box(
        'product-artist',
        __('Artist'),
        'pcr_artist_meta_box_callback',
        'product',
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'pcr_add_artist_meta_box');

/**
 * Artist meta box callback - simple text input
 */
function pcr_artist_meta_box_callback($post) {
    $terms = wp_get_post_terms($post->ID, 'product_artist');
    $artist_name = !empty($terms) ? $terms[0]->name : '';
    
    echo '<label for="product_artist_input">' . __('Artist Name:') . '</label>';
    echo '<input type="text" id="product_artist_input" name="product_artist_input" value="' . esc_attr($artist_name) . '" style="width: 100%; margin-top: 5px;" />';
    echo '<p class="description">Enter the artist name. This will be used for filtering and links.</p>';
}

/**
 * Save artist when product is saved
 */
function pcr_save_artist_meta_box($post_id) {
    if (!isset($_POST['product_artist_input'])) {
        return;
    }

    $artist_name = sanitize_text_field($_POST['product_artist_input']);
    
    if (!empty($artist_name)) {
        // Set the artist term
        wp_set_object_terms($post_id, $artist_name, 'product_artist');
    } else {
        // Remove artist if empty
        wp_set_object_terms($post_id, array(), 'product_artist');
    }
}
add_action('save_post_product', 'pcr_save_artist_meta_box');

/**
 * Helper function to get artist name for a product
 */
function pcr_get_product_artist($product_id = null) {
    if (!$product_id) {
        global $post;
        $product_id = $post->ID;
    }
    
    $terms = wp_get_post_terms($product_id, 'product_artist');
    return !empty($terms) ? $terms[0]->name : '';
}

/**
 * Helper function to get artist link for a product
 */
function pcr_get_product_artist_link($product_id = null) {
    if (!$product_id) {
        global $post;
        $product_id = $post->ID;
    }
    
    $terms = wp_get_post_terms($product_id, 'product_artist');
    if (!empty($terms)) {
        $artist_url = get_term_link($terms[0]);
        return '<a href="' . esc_url($artist_url) . '">' . esc_html($terms[0]->name) . '</a>';
    }
    return '';
}

/**
 * Shortcode to display artist link [pcr_artist_link]
 */
function pcr_artist_link_shortcode($atts) {
    $atts = shortcode_atts(array(
        'id' => null,
        'format' => 'link', // 'link' or 'name'
    ), $atts);
    
    $product_id = $atts['id'] ? $atts['id'] : get_the_ID();
    
    if ($atts['format'] === 'name') {
        return pcr_get_product_artist($product_id);
    } else {
        return pcr_get_product_artist_link($product_id);
    }
}
add_shortcode('pcr_artist_link', 'pcr_artist_link_shortcode');

/**
 * Shortcode to display product title without artist [pcr_album_title]
 */
function pcr_album_title_shortcode($atts) {
    $atts = shortcode_atts(array(
        'id' => null,
    ), $atts);
    
    $product_id = $atts['id'] ? $atts['id'] : get_the_ID();
    $full_title = get_the_title($product_id);
    $artist_name = pcr_get_product_artist($product_id);
    
    if (empty($artist_name)) {
        return $full_title;
    }
    
    // Ensure we're working with UTF-8 strings
    $full_title = mb_convert_encoding($full_title, 'UTF-8', 'UTF-8');
    $artist_name = mb_convert_encoding($artist_name, 'UTF-8', 'UTF-8');
    
    // Clean up invisible Unicode characters that might cause issues
    $full_title = pcr_clean_unicode_chars($full_title);
    $artist_name = pcr_clean_unicode_chars($artist_name);
    
    // More comprehensive pattern to match various separators and invisible chars
    $separators = [
        '-',        // regular hyphen
        '–',        // en dash (U+2013)
        '—',        // em dash (U+2014)
        '−',        // minus sign (U+2212)
        '‒',        // figure dash (U+2012)
        '⁃',        // hyphen bullet (U+2043)
    ];
    
    $separator_pattern = implode('|', array_map('preg_quote', $separators));
    
    // Pattern explanation:
    // ^                    - start of string
    // \s*                  - optional whitespace
    // preg_quote(artist)   - escaped artist name
    // \s*                  - optional whitespace
    // (?:separator)*       - optional separators (non-capturing group)
    // \s*                  - optional whitespace
    $pattern = '/^\s*' . preg_quote($artist_name, '/') . '\s*(?:' . $separator_pattern . ')*\s*/u';
    
    $album_title = preg_replace($pattern, '', $full_title);
    
    // Clean up any remaining artifacts
    $album_title = pcr_clean_unicode_chars($album_title);
    $album_title = trim($album_title);
    
    // If nothing remains after stripping, return original title
    if (empty($album_title)) {
        return $full_title;
    }
    
    return $album_title;
}
add_shortcode('pcr_album_title', 'pcr_album_title_shortcode');

/**
 * Helper function to clean problematic Unicode characters
 */
function pcr_clean_unicode_chars($string) {
    // Remove common invisible/problematic Unicode characters
    $invisible_chars = [
        "\u{200E}", // Left-to-right mark
        "\u{200F}", // Right-to-left mark
        "\u{202A}", // Left-to-right embedding
        "\u{202B}", // Right-to-left embedding
        "\u{202C}", // Pop directional formatting
        "\u{202D}", // Left-to-right override
        "\u{202E}", // Right-to-left override
        "\u{2060}", // Word joiner
        "\u{FEFF}", // Zero width no-break space (BOM)
        "\u{200B}", // Zero width space
        "\u{200C}", // Zero width non-joiner
        "\u{200D}", // Zero width joiner
    ];
    
    foreach ($invisible_chars as $char) {
        $string = str_replace($char, '', $string);
    }
    
    // Also remove any remaining replacement characters
    $string = str_replace('�', '', $string);
    
    return $string;
}

/**
 * Debug function to analyze Unicode characters in a string
 * Remove this after debugging
 */
function pcr_debug_unicode($string, $label = '') {
    if (WP_DEBUG) {
        $chars = preg_split('//u', $string, -1, PREG_SPLIT_NO_EMPTY);
        $debug_info = [];
        foreach ($chars as $char) {
            $debug_info[] = $char . ' (U+' . sprintf('%04X', mb_ord($char, 'UTF-8')) . ')';
        }
        error_log($label . ': ' . implode(' | ', $debug_info));
    }
}

/**
 * Your other WooCommerce customizations go below this line
 */